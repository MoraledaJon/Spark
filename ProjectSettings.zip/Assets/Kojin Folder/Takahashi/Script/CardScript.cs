using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CardScript : MonoBehaviour
{

    //ボタン押したら別のsceneに行く
    //public void CardGameStart()
    //{
    //    SceneManager.LoadScene("PosePose");
    //}
}
